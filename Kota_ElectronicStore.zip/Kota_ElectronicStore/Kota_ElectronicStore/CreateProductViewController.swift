//
//  CreateProductViewController.swift
//  Kota_ElectronicStore
//
//  Created by Kota,Manoj on 4/26/22.
//

import UIKit

class CreateProductViewController: UIViewController {

    
    @IBOutlet weak var ProductNameOutlet: UITextField!
    
    @IBOutlet weak var ProductPriceOutlet: UITextField!
   
    


    
    override func viewDidLoad() {
        super.viewDidLoad()

        var newProduct = [ProductNameOutlet.text!,ProductPriceOutlet.text!]
        Electronic.append(newProduct)
    }
    
    @IBAction func Button(_ sender: UIButton) {
        var newProduct = [ProductNameOutlet.text!,ProductPriceOutlet.text!]
        Electronic.append(newProduct)
    }

   
}
