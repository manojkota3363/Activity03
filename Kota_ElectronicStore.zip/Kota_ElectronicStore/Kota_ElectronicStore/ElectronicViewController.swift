//
//  ViewController.swift
//  Kota_ElectronicStore
//
//  Created by Kota,Manoj on 4/26/22.
//

import UIKit

class ElectronicViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Electronic.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a cell
        let cell = TableViewOulet.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
               
               //Assign the data to the cell.
               cell.textLabel?.text = Electronic[indexPath.row][0]
               
               //return cell
               return cell
    }
    



   
    @IBOutlet weak var TableViewOulet: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        TableViewOulet.reloadData()
        TableViewOulet.title="TableViewOulet"
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        TableViewOulet.delegate = self
        TableViewOulet.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           let transition = segue.identifier
           if transition == "DetailsSegue"{
               let destination  = segue.destination as! DetailViewController
               
               destination.product = Electronic[(TableViewOulet.indexPathForSelectedRow?.row)!]
           }
        if transition == "productUpdatesegue"{
            _  = segue.destination as! CreateProductViewController
            
           
        }
       }

}

