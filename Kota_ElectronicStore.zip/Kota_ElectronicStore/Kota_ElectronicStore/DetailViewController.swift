//
//  DetailViewController.swift
//  Kota_ElectronicStore
//
//  Created by Kota,Manoj on 4/26/22.
//

import UIKit

class DetailViewController: UIViewController {
    var product = [String]()
    
    @IBOutlet weak var NameOutlet: UILabel!
    
    @IBOutlet weak var productOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NameOutlet.text=product[0];
        productOutlet.text=product[1];
       
    }
    

    

}
